function [T1, T2] = non(V1,tf1,w1,V2,tf2,td2)
tor1=tor11*cos(tf1)+tor22*cos(tf1+tf2);
tor2=tor22*cos(tf1+tf2);
T1=(I11+2*I21*cos(tf2)+I22)*V1+(I21*cos(tf2)+I22)*V2+I21*sin(tf2)*(w1^2-td2^2)+g*tor1;
T2=V1*(I21*cos(tf2)+I22)+I22*V2+I21*sin(tf2)*w1^2+g*tor2;
end