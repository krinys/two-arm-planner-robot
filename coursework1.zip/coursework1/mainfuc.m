m=1;
m1=m;
m2=m;
L1cg=0.5;
L2cg=0.5;
sqk1cg=0.0833;
sqk2cg=0.0833;
I11=m1*(L1cg^2+sqk1cg)+M1*(L1^2)+(m2+M2)*(L1^2);
I21=(m2*L2cg+M2*L2)*L1;
I22=m2*(L2cg*L2cg+sqk2cg)+M2*L2*L2;
tor11=(m1*L1cg+m2*L1+M1*L1+M2*L1);
tor22=(m2*L2cg+M2*L2);
mu1=0.1;
mu=0.1;
mu2=mu;
omg=1;
omg1=omg;
omg2=omg;
tou=1;
tou1=tou;
tou2=tou;
M1=mu1*m;
M2=mu2*m;

g=0;





